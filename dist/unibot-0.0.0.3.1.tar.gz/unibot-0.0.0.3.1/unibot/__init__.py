# -*- coding: utf-8 -*-
__author__ = 'Shaon Majumder'
__email__ = 'smazoomder@gmail.com'
__version__ = '0.0.0.1.1'